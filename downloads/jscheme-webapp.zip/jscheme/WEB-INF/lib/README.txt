Licences and home URLs for all jar files in this folder...

hsqldb-*.jar  The Hypersonic SQL Database system, from the hsqldb.sourceforge.net site, HSQLDB Licence

jscheme-*.jar -- the JScheme jar from jscheme.sourceforge.net, zlib/png License.

mail-*.jar --  http://java.sun.com/products/javamail/, Sun Binary Code License Agreement

activation-*.jar -- The JavaBeans Activation Framework, needed by mail.jar, 
                http://java.sun.com/products/javabeans/glasgow/jaf.html, Sun Binary Code License Agreement

mysql-connector-java-*.jar -- we'll upgrade to the lastest jar from http://dev.mysql.com/downloads/connector/j/3.0.html

multipartformreader.jar -- the MultipartFormReader class from the Java Snippets site http://sourceforge.net/snippet/browse.php?by=lang&lang=8, GPL

commons-fileupload-*.jar -- another multipart form reader, Apache Software license, from http://jakarta.apache.org/commons/fileupload/